<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/dash.html.twig */
class __TwigTemplate_69161c3f1ce0992484abd82ea26c6cdc0269c389b058c0df2d1ae92990e2745c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "user/dash.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Hello UserController!";
    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<div class=\"userdash\">
<p><b>";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 8), "email", [], "any", false, false, false, 8), "html", null, true);
        echo "</b></p>


<a href=\"";
        // line 11
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
        echo "\" class=\"logout\">Exit</a>


";
        // line 14
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        echo "
<div class=\"user\">
";
        // line 16
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "userid", [], "any", false, false, false, 16), 'row', ["value" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 16), "id", [], "any", false, false, false, 16)]);
        echo "
</div>
<div class=\"check\">
";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["form"] ?? null), "check", [], "any", false, false, false, 19), 'row', ["label" => "Check Orders"]);
        echo "
</div>
";
        // line 21
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        echo "
</div>
<style>

.user{
visibility: hidden;
}
.userdash{
color: black;
margin-left: 1000px;
}
.check button{
color: white;
background-color: purple;
border: 1px solid white;
border-radius: 20px;
height: 25px;
width: 250px;
font-size: 20px;
margin-left: 100px;
}
.logout{
color: black;
text-decoration: none;
margin-left: 100px;
}
.profile{
color: white;
text-decoration: none;
margin-left: 900px;
}

@media (max-width: 576px){

.check button{
color: white;
background-color: purple;
border: 1px solid white;
border-radius: 20px;
height: 25px;
width: 250px;
font-size: 20px;
margin-left: 10px;
margin-top: 10px;
}
.userdash{
color: black;
margin-left: 100px;
margin-top: 350px;
}
.logout{
color: black;
text-decoration: none;
font-weight: bold;
}
}
</style>

";
    }

    public function getTemplateName()
    {
        return "user/dash.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 21,  85 => 19,  79 => 16,  74 => 14,  68 => 11,  62 => 8,  58 => 6,  54 => 5,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "user/dash.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/user/dash.html.twig");
    }
}
