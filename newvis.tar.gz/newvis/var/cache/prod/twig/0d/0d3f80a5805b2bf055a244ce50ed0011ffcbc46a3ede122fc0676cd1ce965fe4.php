<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* offers/show.html.twig */
class __TwigTemplate_3d37854fd6668c9157ed7c6170b10791d0c44354cc95a69ee35bb6973c6550f4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "offers/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "
<link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/css/show-offer.css"), "html", null, true);
        echo "\" />

    <table class=\"table\">
        <tbody>

            <tr>
            <th></th>
                <td><p class=\"name\">";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["offer"] ?? null), "name", [], "any", false, false, false, 14), "html", null, true);
        echo "</p></td>
            </tr>
            <tr>
                <th></th>
                <td><p class=\"desc\">";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["offer"] ?? null), "descriptions", [], "any", false, false, false, 18), "html", null, true);
        echo "</p></td>
            </tr>
            <tr>
                <th></th>
                <td><p class=\"price\">\$";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["offer"] ?? null), "price", [], "any", false, false, false, 22), "html", null, true);
        echo "</p></td>
            </tr>
            <tr>

            <td><p class=\"btn-order\"><a href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("offers_buy", ["id" => twig_get_attribute($this->env, $this->source, ($context["offer"] ?? null), "id", [], "any", false, false, false, 26)]), "html", null, true);
        echo "\">ORDER</a></p></td>
            </tr>

        </tbody>
    </table>
<a href=\"";
        // line 31
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("offers_index");
        echo "\" class=\"back\">back to offers</a>


";
    }

    public function getTemplateName()
    {
        return "offers/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 31,  84 => 26,  77 => 22,  70 => 18,  63 => 14,  53 => 7,  50 => 6,  46 => 5,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "offers/show.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/offers/show.html.twig");
    }
}
