<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* team/edit.html.twig */
class __TwigTemplate_7e8e458229cb49145f5d4688199149cf90c62b4c1579a940c0bfac15ab45808e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "
";
        // line 2
        $this->displayBlock('title', $context, $blocks);
        // line 3
        echo "
";
        // line 4
        $this->displayBlock('body', $context, $blocks);
    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Edit Team";
    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 5
        echo "    <h1>Edit Team</h1>

    ";
        // line 7
        echo twig_include($this->env, $context, "team/_form.html.twig", ["button_label" => "Update"]);
        echo "

    ";
        // line 9
        echo twig_include($this->env, $context, "team/_delete_form.html.twig");
        echo "


";
    }

    public function getTemplateName()
    {
        return "team/edit.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  71 => 9,  66 => 7,  62 => 5,  58 => 4,  51 => 2,  47 => 4,  44 => 3,  42 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "team/edit.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/team/edit.html.twig");
    }
}
