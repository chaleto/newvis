<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* support/support.html.twig */
class __TwigTemplate_d7b7b435a6daf579a268c12b4e734df8f6b80f621f26e268d23da63f9727b16b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "support/support.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "
<div class=\"reclame\">

<p>We know that starting a new business is not very easy. Especially in the era of technologies where everything goes digital it is almost impossible to show ideas or products without publishing it in the virtual world  !</p>

<p>So now you will ask how to do it ? </p>

<p><b>The solution is very easy !</b></p>
<span class=\"rec\"><p>Our team from  <span class=\"nv\"><a href=\"";
        // line 16
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("about");
        echo "\">New Vision</a></span> gives to you the best performance about your business and ideas, but so let's do not talk anymore and just check out our <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("offers_index");
        echo "\" class=\"offa\"><span class=\"offer\">offers !</span></a></p></span>

</div>



";
    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 5
        echo "<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\HttpFoundationExtension']->generateAbsoluteUrl($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/css/support.css")), "html", null, true);
        echo "\" />

       ";
    }

    public function getTemplateName()
    {
        return "support/support.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 5,  76 => 4,  63 => 16,  53 => 8,  51 => 4,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "support/support.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/support/support.html.twig");
    }
}
