<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* offers/index.html.twig */
class __TwigTemplate_5cb2b450fea9c053bab3623c5d985094546aaa8e972ea4e4b7dce2a3db768ceb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "offers/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/css/offers.css"), "html", null, true);
        echo "\" />





<div class=\"offers-move\">
    <table class=\"table\">

";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["offers"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["offer"]) {
            // line 16
            echo "        <tbody>

            <tr>
                <td>
                   ";
            // line 20
            if ( !twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 20)) {
                // line 21
                echo "                    <a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("offers_show", ["id" => twig_get_attribute($this->env, $this->source, $context["offer"], "id", [], "any", false, false, false, 21)]), "html", null, true);
                echo "\" class=\"show\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offer"], "name", [], "any", false, false, false, 21), "html", null, true);
                echo "</a>

                    ";
            } elseif (twig_get_attribute($this->env, $this->source,             // line 23
($context["app"] ?? null), "user", [], "any", false, false, false, 23)) {
                // line 24
                echo "                      <a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("offers_buy", ["id" => twig_get_attribute($this->env, $this->source, $context["offer"], "id", [], "any", false, false, false, 24)]), "html", null, true);
                echo "\" class=\"show\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offer"], "name", [], "any", false, false, false, 24), "html", null, true);
                echo "</a>


        ";
            } else {
                // line 28
                echo "            <tr>
                <td colspan=\"5\">no records found</td>
            </tr>
            ";
            }
            // line 32
            echo "
        </tbody>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['offer'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "    </table>

</div>

";
    }

    public function getTemplateName()
    {
        return "offers/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 35,  101 => 32,  95 => 28,  85 => 24,  83 => 23,  75 => 21,  73 => 20,  67 => 16,  63 => 15,  50 => 6,  46 => 5,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "offers/index.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/offers/index.html.twig");
    }
}
