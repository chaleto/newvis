<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* main/contact.html.twig */
class __TwigTemplate_b1538d554a1201d2425750787db7f6469c92acf4c0cad1c03b9a40578b17be07 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "main/contact.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "main/contact.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "main/contact.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "
";
        // line 4
        if ( !twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 4, $this->source); })()), "user", [], "any", false, false, false, 4)) {
            // line 5
            echo "<div class=\"email\">
<h1 style=\"color: violet;\">If you need help just text us ! </p>
";
            // line 7
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 7, $this->source); })()), 'form_start');
            echo "

";
            // line 9
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 9, $this->source); })()), "email", [], "any", false, false, false, 9), 'row');
            echo "

";
            // line 11
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 11, $this->source); })()), "text", [], "any", false, false, false, 11), 'row');
            echo "

";
            // line 13
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 13, $this->source); })()), "Send", [], "any", false, false, false, 13), 'row');
            echo "

";
            // line 15
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 15, $this->source); })()), 'form_end');
            echo "
</div>
";
        } else {
            // line 18
            echo "
<div class=\"email\">
<h1 style=\"color: violet;\">If you need help just text us ! </p>
";
            // line 21
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 21, $this->source); })()), 'form_start');
            echo "

";
            // line 23
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 23, $this->source); })()), "email", [], "any", false, false, false, 23), 'row', ["value" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 23, $this->source); })()), "user", [], "any", false, false, false, 23), "email", [], "any", false, false, false, 23)]);
            echo "

";
            // line 25
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 25, $this->source); })()), "text", [], "any", false, false, false, 25), 'row');
            echo "

";
            // line 27
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 27, $this->source); })()), "Send", [], "any", false, false, false, 27), 'row');
            echo "

";
            // line 29
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["emailform"]) || array_key_exists("emailform", $context) ? $context["emailform"] : (function () { throw new RuntimeError('Variable "emailform" does not exist.', 29, $this->source); })()), 'form_end');
            echo "
</div>

";
        }
        // line 33
        echo "<style>

.email{
margin-left: 1200px;
margin-top: 50px;
}
button{
width: 200px;
height: 30px;
border-radius: 10px;
}
textarea{
width: 300px;
height: 100px;
border-radius: 10px;
}
input{
width:300px;
border-radius: 10px;
height: 30px;
}
::placeholder{
text-align: center;
}
@media (max-width: 576px){
.email{
margin-left: 10px;
margin-top: 250px;
line-height: 30px;
text-align: center;
}

}
</style>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "main/contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 33,  128 => 29,  123 => 27,  118 => 25,  113 => 23,  108 => 21,  103 => 18,  97 => 15,  92 => 13,  87 => 11,  82 => 9,  77 => 7,  73 => 5,  71 => 4,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}

{% if not app.user %}
<div class=\"email\">
<h1 style=\"color: violet;\">If you need help just text us ! </p>
{{form_start(emailform)}}

{{form_row(emailform.email)}}

{{form_row(emailform.text)}}

{{form_row(emailform.Send)}}

{{form_end(emailform)}}
</div>
{%else%}

<div class=\"email\">
<h1 style=\"color: violet;\">If you need help just text us ! </p>
{{form_start(emailform)}}

{{form_row(emailform.email,{'value': app.user.email})}}

{{form_row(emailform.text)}}

{{form_row(emailform.Send)}}

{{form_end(emailform)}}
</div>

{%endif %}
<style>

.email{
margin-left: 1200px;
margin-top: 50px;
}
button{
width: 200px;
height: 30px;
border-radius: 10px;
}
textarea{
width: 300px;
height: 100px;
border-radius: 10px;
}
input{
width:300px;
border-radius: 10px;
height: 30px;
}
::placeholder{
text-align: center;
}
@media (max-width: 576px){
.email{
margin-left: 10px;
margin-top: 250px;
line-height: 30px;
text-align: center;
}

}
</style>

{% endblock %}
", "main/contact.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/main/contact.html.twig");
    }
}
