<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_61d2aac208ca8b4b978a87882347313500fe929228a3c8af81283450823331e6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
      <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, height=device-height initial-scale=1.0\">
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "    </head>
    <body>
      <script src=\"https://code.jquery.com/jquery-3.4.1.js\"></script>
      <script src=\"https://kit.fontawesome.com/a076d05399.js\"></script>


<link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/css/base.css"), "html", null, true);
        echo "\" />

<div class=\"btn\">
     <span class=\"fas fa-bars\"></span>
   </div>
<nav class=\"sidebar\">
     <div class=\"text\"> Menu</div>
<ul>
<li class=\"active\"><a href=\"";
        // line 22
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("main");
        echo "\">Home</a></li>
<li>
  ";
        // line 24
        if ( !twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 24, $this->source); })()), "user", [], "any", false, false, false, 24)) {
            // line 25
            echo "         <a href=\"#\" class=\"feat-btn\">User
           <span class=\"fas fa-caret-down first\"></span>
         </a>
         <ul class=\"feat-show\">
<li><a href=\"";
            // line 29
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_login");
            echo "\">Login</a></li>
<li><a href=\"";
            // line 30
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_register");
            echo "\">Registration</a></li>
</ul>
";
        } else {
            // line 33
            echo "<a href=\"#\" class=\"feat-btn\">User
  <span class=\"fas fa-caret-down first\"></span>
</a>
<ul class=\"feat-show\">
<li><a href=\"";
            // line 37
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user");
            echo "\">Profile</a></li>
<li><a href=\"";
            // line 38
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Log Out</a></li>
</ul>

";
        }
        // line 42
        echo "</li>
<li>
         <a href=\"#\" class=\"serv-btn\">Services
           <span class=\"fas fa-caret-down second\"></span>
         </a>
         <ul class=\"serv-show\">
<li><a href=\"";
        // line 48
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("support");
        echo "\">Web Development</a></li>
</ul>
</li>
<li><a href=\"";
        // line 51
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("about");
        echo "\">About</a></li>
<li><a href=\"";
        // line 52
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contacts");
        echo "\">Contact Us</a></li>
</ul>
</nav>

<script>
   \$('.btn').click(function(){
     \$(this).toggleClass(\"click\");
     \$('.sidebar').toggleClass(\"show\");

   });
     \$('.feat-btn').click(function(){
       \$('nav ul .feat-show').toggleClass(\"show\");
       \$('nav ul .first').toggleClass(\"rotate\");
     });
     \$('.serv-btn').click(function(){
       \$('nav ul .serv-show').toggleClass(\"show1\");
       \$('nav ul .second').toggleClass(\"rotate\");
     });
     \$('nav ul li').click(function(){
       \$(this).addClass(\"active\").siblings().removeClass(\"active\");
     });
   </script>

  <h1 class=\"moto\">TOGETHER WE DESIGN THE FUTURE</h1>



        ";
        // line 79
        $this->displayBlock('body', $context, $blocks);
        // line 81
        echo "

    </body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "New Vision";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 79
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 80
        echo "        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 80,  219 => 79,  201 => 7,  182 => 6,  168 => 81,  166 => 79,  136 => 52,  132 => 51,  126 => 48,  118 => 42,  111 => 38,  107 => 37,  101 => 33,  95 => 30,  91 => 29,  85 => 25,  83 => 24,  78 => 22,  67 => 14,  59 => 8,  57 => 7,  53 => 6,  46 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
      <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, height=device-height initial-scale=1.0\">
        <title>{% block title %}New Vision{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
    </head>
    <body>
      <script src=\"https://code.jquery.com/jquery-3.4.1.js\"></script>
      <script src=\"https://kit.fontawesome.com/a076d05399.js\"></script>


<link rel=\"stylesheet\" href=\"{{asset('/css/base.css')}}\" />

<div class=\"btn\">
     <span class=\"fas fa-bars\"></span>
   </div>
<nav class=\"sidebar\">
     <div class=\"text\"> Menu</div>
<ul>
<li class=\"active\"><a href=\"{{path('main')}}\">Home</a></li>
<li>
  {% if not app.user %}
         <a href=\"#\" class=\"feat-btn\">User
           <span class=\"fas fa-caret-down first\"></span>
         </a>
         <ul class=\"feat-show\">
<li><a href=\"{{path('app_login')}}\">Login</a></li>
<li><a href=\"{{path('app_register')}}\">Registration</a></li>
</ul>
{% else %}
<a href=\"#\" class=\"feat-btn\">User
  <span class=\"fas fa-caret-down first\"></span>
</a>
<ul class=\"feat-show\">
<li><a href=\"{{path('user')}}\">Profile</a></li>
<li><a href=\"{{path('app_logout')}}\">Log Out</a></li>
</ul>

{% endif %}
</li>
<li>
         <a href=\"#\" class=\"serv-btn\">Services
           <span class=\"fas fa-caret-down second\"></span>
         </a>
         <ul class=\"serv-show\">
<li><a href=\"{{path('support')}}\">Web Development</a></li>
</ul>
</li>
<li><a href=\"{{path('about')}}\">About</a></li>
<li><a href=\"{{path('contacts')}}\">Contact Us</a></li>
</ul>
</nav>

<script>
   \$('.btn').click(function(){
     \$(this).toggleClass(\"click\");
     \$('.sidebar').toggleClass(\"show\");

   });
     \$('.feat-btn').click(function(){
       \$('nav ul .feat-show').toggleClass(\"show\");
       \$('nav ul .first').toggleClass(\"rotate\");
     });
     \$('.serv-btn').click(function(){
       \$('nav ul .serv-show').toggleClass(\"show1\");
       \$('nav ul .second').toggleClass(\"rotate\");
     });
     \$('nav ul li').click(function(){
       \$(this).addClass(\"active\").siblings().removeClass(\"active\");
     });
   </script>

  <h1 class=\"moto\">TOGETHER WE DESIGN THE FUTURE</h1>



        {% block body %}
        {% endblock %}


    </body>
</html>
", "base.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/base.html.twig");
    }
}
