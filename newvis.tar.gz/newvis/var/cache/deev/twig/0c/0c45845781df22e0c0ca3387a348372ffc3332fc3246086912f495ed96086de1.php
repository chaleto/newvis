<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/dash.html.twig */
class __TwigTemplate_c20d43c10d803416af06af43a2e09e80c03ae1a59a7af8261f5f1b948a33056c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/dash.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "user/dash.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello UserController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
<div class=\"userdash\">
<p><b>";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 8, $this->source); })()), "user", [], "any", false, false, false, 8), "email", [], "any", false, false, false, 8), "html", null, true);
        echo "</b></p>


<a href=\"";
        // line 11
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
        echo "\" class=\"logout\">Exit</a>


";
        // line 14
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 14, $this->source); })()), 'form_start');
        echo "
<div class=\"user\">
";
        // line 16
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 16, $this->source); })()), "userid", [], "any", false, false, false, 16), 'row', ["value" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "user", [], "any", false, false, false, 16), "id", [], "any", false, false, false, 16)]);
        echo "
</div>
<div class=\"check\">
";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 19, $this->source); })()), "check", [], "any", false, false, false, 19), 'row', ["label" => "Check Orders"]);
        echo "
</div>
";
        // line 21
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 21, $this->source); })()), 'form_end');
        echo "
</div>
<style>

.user{
visibility: hidden;
}
.userdash{
color: black;
margin-left: 1000px;
}
.check button{
color: white;
background-color: purple;
border: 1px solid white;
border-radius: 20px;
height: 25px;
width: 250px;
font-size: 20px;
margin-left: 100px;
}
.logout{
color: black;
text-decoration: none;
margin-left: 100px;
}
.profile{
color: white;
text-decoration: none;
margin-left: 900px;
}

@media (max-width: 576px){

.check button{
color: white;
background-color: purple;
border: 1px solid white;
border-radius: 20px;
height: 25px;
width: 250px;
font-size: 20px;
margin-left: 10px;
margin-top: 10px;
}
.userdash{
color: black;
margin-left: 100px;
margin-top: 350px;
}
.logout{
color: black;
text-decoration: none;
font-weight: bold;
}
}
</style>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "user/dash.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 21,  100 => 19,  94 => 16,  89 => 14,  83 => 11,  77 => 8,  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello UserController!{% endblock %}

{% block body %}

<div class=\"userdash\">
<p><b>{{app.user.email}}</b></p>


<a href=\"{{path('app_logout')}}\" class=\"logout\">Exit</a>


{{form_start(form)}}
<div class=\"user\">
{{form_row(form.userid, {'value':app.user.id})}}
</div>
<div class=\"check\">
{{form_row(form.check, {'label': 'Check Orders'})}}
</div>
{{form_end(form)}}
</div>
<style>

.user{
visibility: hidden;
}
.userdash{
color: black;
margin-left: 1000px;
}
.check button{
color: white;
background-color: purple;
border: 1px solid white;
border-radius: 20px;
height: 25px;
width: 250px;
font-size: 20px;
margin-left: 100px;
}
.logout{
color: black;
text-decoration: none;
margin-left: 100px;
}
.profile{
color: white;
text-decoration: none;
margin-left: 900px;
}

@media (max-width: 576px){

.check button{
color: white;
background-color: purple;
border: 1px solid white;
border-radius: 20px;
height: 25px;
width: 250px;
font-size: 20px;
margin-left: 10px;
margin-top: 10px;
}
.userdash{
color: black;
margin-left: 100px;
margin-top: 350px;
}
.logout{
color: black;
text-decoration: none;
font-weight: bold;
}
}
</style>

{% endblock %}
", "user/dash.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/user/dash.html.twig");
    }
}
