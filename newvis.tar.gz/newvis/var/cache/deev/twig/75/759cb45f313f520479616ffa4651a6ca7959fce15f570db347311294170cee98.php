<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* offers/index.html.twig */
class __TwigTemplate_b71423e1dab6cce17c4a3ad5246be84878b7b4d24ad699f3135d9a4ca95cc2bb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "offers/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "offers/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/css/offers.css"), "html", null, true);
        echo "\" />





<div class=\"offers-move\">
    <table class=\"table\">

";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["offers"]) || array_key_exists("offers", $context) ? $context["offers"] : (function () { throw new RuntimeError('Variable "offers" does not exist.', 15, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["offer"]) {
            // line 16
            echo "        <tbody>

            <tr>
                <td>
                   ";
            // line 20
            if ( !twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 20, $this->source); })()), "user", [], "any", false, false, false, 20)) {
                // line 21
                echo "                    <a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("offers_show", ["id" => twig_get_attribute($this->env, $this->source, $context["offer"], "id", [], "any", false, false, false, 21)]), "html", null, true);
                echo "\" class=\"show\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offer"], "name", [], "any", false, false, false, 21), "html", null, true);
                echo "</a>

                    ";
            } elseif (twig_get_attribute($this->env, $this->source,             // line 23
(isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 23, $this->source); })()), "user", [], "any", false, false, false, 23)) {
                // line 24
                echo "                      <a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("offers_buy", ["id" => twig_get_attribute($this->env, $this->source, $context["offer"], "id", [], "any", false, false, false, 24)]), "html", null, true);
                echo "\" class=\"show\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offer"], "name", [], "any", false, false, false, 24), "html", null, true);
                echo "</a>


        ";
            } else {
                // line 28
                echo "            <tr>
                <td colspan=\"5\">no records found</td>
            </tr>
            ";
            }
            // line 32
            echo "
        </tbody>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['offer'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "    </table>

</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "offers/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 35,  110 => 32,  104 => 28,  94 => 24,  92 => 23,  84 => 21,  82 => 20,  76 => 16,  72 => 15,  59 => 6,  52 => 5,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}



{% block body %}
<link rel=\"stylesheet\" href=\"{{asset('/css/offers.css')}}\" />





<div class=\"offers-move\">
    <table class=\"table\">

{% for offer in offers %}
        <tbody>

            <tr>
                <td>
                   {% if not app.user %}
                    <a href=\"{{ path('offers_show', {'id': offer.id}) }}\" class=\"show\">{{offer.name}}</a>

                    {% elseif app.user %}
                      <a href=\"{{ path('offers_buy', {'id': offer.id}) }}\" class=\"show\">{{offer.name}}</a>


        {% else %}
            <tr>
                <td colspan=\"5\">no records found</td>
            </tr>
            {% endif %}

        </tbody>
          {% endfor %}
    </table>

</div>

{% endblock %}
", "offers/index.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/offers/index.html.twig");
    }
}
