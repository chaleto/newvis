<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* team/milev.html.twig */
class __TwigTemplate_c02b55bba0345c6d8d1fada7eec2c83da906c33d754c90fe2787f96acbbe1693 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "team/milev.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "team/milev.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<div class=\"me\">
<p>Born in 1998, in Petrich,Bulgaria</p>
<p>Stoyan Milev is self-taught developer with passion in web-development, whos favourite programming language is  PHP.</p>
<p>He has coded on different programming languages like Python,C#,JS, but his \"big love\" is PHP.</p>
<p>He starts with front-end website development and continues with backend databases development.</p>
<p>At the moment he uses PHP Symfony for developing his projects.</p>
<p>Highly motivated person chasing his OWN dreams !</p>
</div>

<style>

@media(max-width: 576px){
.me{
margin-top: 250px;
color: white;
font-weight: bold;
line-height: 30px;
}
}

</style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "team/milev.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  59 => 4,  52 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}

<div class=\"me\">
<p>Born in 1998, in Petrich,Bulgaria</p>
<p>Stoyan Milev is self-taught developer with passion in web-development, whos favourite programming language is  PHP.</p>
<p>He has coded on different programming languages like Python,C#,JS, but his \"big love\" is PHP.</p>
<p>He starts with front-end website development and continues with backend databases development.</p>
<p>At the moment he uses PHP Symfony for developing his projects.</p>
<p>Highly motivated person chasing his OWN dreams !</p>
</div>

<style>

@media(max-width: 576px){
.me{
margin-top: 250px;
color: white;
font-weight: bold;
line-height: 30px;
}
}

</style>
{% endblock %}
", "team/milev.html.twig", "/opt/lampp/htdocs/projects/newvis/templates/team/milev.html.twig");
    }
}
